/*
 * Translated default messages for bootstrap-select.
 * Locale: PT (Portuguese; português)
 * Region: BR (Brazil; Brasil)
 * Author: Rodrigo de Avila <rodrigo@avila.net.br>
 */

!function(a){a.fn.selectpicker.defaults={style:"btn-default",size:"auto",title:null,selectedTextFormat:"values",noneSelectedText:"Nada selecionado",noneResultsText:"Nada encontrado contendo",countSelectedText:"Selecionado {0} de {1}",maxOptionsText:["Limite excedido (m\xe1x. {n} {var})","Limite do grupo excedido (m\xe1x. {n} {var})",["itens","item"]],width:!1,container:!1,hideDisabled:!1,showSubtext:!1,showIcon:!0,showContent:!0,dropupAuto:!0,header:!1,liveSearch:!1,actionsBox:!1,multipleSeparator:", ",iconBase:"glyphicon",tickIcon:"glyphicon-ok",maxOptions:!1}}(jQuery);
